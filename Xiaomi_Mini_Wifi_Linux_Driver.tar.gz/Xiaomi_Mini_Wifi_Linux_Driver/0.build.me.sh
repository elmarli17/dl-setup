#!/bin/sh

echo "Removing prev module..."
sudo rmmod mt7601Usta
echo "Building driver..."
CFLAGS="-O0 -march=x86" make
echo "Testing module..."
sudo insmod os/linux/mt7601Usta.ko
echo "Installing..."
sudo make install
echo "Done!"
